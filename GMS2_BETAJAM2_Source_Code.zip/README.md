# GMS2_BETAJAM2
This project is for the Gamemaker Studio 2 Beta Jam on itch.io
